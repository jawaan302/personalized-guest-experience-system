-- Drop the existing database if it exists
DROP DATABASE IF EXISTS personalized_guest_experience_db;

-- Create the database
CREATE DATABASE personalized_guest_experience_db;

-- Use the created database
USE personalized_guest_experience_db;

-- Create Users table
CREATE TABLE Users (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Username VARCHAR(50) NOT NULL,
    Password VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    UserType ENUM('Guest', 'HotelStaff') NOT NULL,
    Preferences TEXT
);

-- Insert sample data into Users table for guests
INSERT INTO Users (Username, Password, Email, UserType, Preferences) VALUES
('guest1', 'password1', 'guest1@example.com', 'Guest', '{"preference1": "value1", "preference2": "value2"}'),
('guest2', 'password2', 'guest2@example.com', 'Guest', '{"preference1": "value1", "preference2": "value2"}'),
('guest3', 'password3', 'guest3@example.com', 'Guest', '{"preference1": "value1", "preference2": "value2"}');

-- Insert sample data into Users table for hotel staff
INSERT INTO Users (Username, Password, Email, UserType) VALUES
('staff1', 'password1', 'staff1@example.com', 'HotelStaff'),
('staff2', 'password2', 'staff2@example.com', 'HotelStaff'),
('staff3', 'password3', 'staff3@example.com', 'HotelStaff');

-- Create PersonalizedGuidelines table
CREATE TABLE PersonalizedGuidelines (
    GuidelineID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    GuidelineText TEXT,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Insert sample data into PersonalizedGuidelines table
INSERT INTO PersonalizedGuidelines (UserID, GuidelineText) VALUES
(1, 'Guideline 1 for guest 1'),
(2, 'Guideline 1 for guest 2'),
(3, 'Guideline 1 for guest 3');

-- Create Notifications table
CREATE TABLE Notifications (
    NotificationID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    NotificationText TEXT,
    Timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Create Feedback table
CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    FeedbackText TEXT,
    Timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Create GuestServiceManagement table
CREATE TABLE GuestServiceManagement (
    ServiceID INT PRIMARY KEY AUTO_INCREMENT,
    StaffID INT,
    UserID INT,
    ServiceType VARCHAR(100),
    Timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (StaffID) REFERENCES Users(UserID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Create SystemConfiguration table
CREATE TABLE SystemConfiguration (
    ConfigID INT PRIMARY KEY AUTO_INCREMENT,
    SettingName VARCHAR(100) NOT NULL,
    SettingValue VARCHAR(255) NOT NULL
);

-- Insert sample data into SystemConfiguration table
INSERT INTO SystemConfiguration (SettingName, SettingValue) VALUES
('MaxGuestsPerRoom', '2'),
('NotificationFrequency', 'Daily');

-- Create TechnicalSupportTickets table
CREATE TABLE TechnicalSupportTickets (
    TicketID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    TicketText TEXT,
    Timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE
);

-- Create RequestRecommendations table
CREATE TABLE RequestRecommendations (
    RequestID INT PRIMARY KEY AUTO_INCREMENT,
    RequestType VARCHAR(100) NOT NULL,
    GuestName VARCHAR(100) NOT NULL,
    RoomNumber INT NOT NULL,
    Email VARCHAR(100) NOT NULL,
    PhoneNumber VARCHAR(20) NOT NULL,
    Preferences TEXT,
    Timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create UserPreferences table
CREATE TABLE UserPreferences (
    PreferenceID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    PreferenceName VARCHAR(100) NOT NULL,
    PreferenceValue TEXT,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Insert sample data into PersonalizedGuidelines table
INSERT INTO PersonalizedGuidelines (UserID, GuidelineText) VALUES
(1, 'Guideline 1: Always greet guests with a warm smile.'),
(1, 'Guideline 2: Provide clear directions to guest rooms and hotel facilities.'),
(1, 'Guideline 3: Offer assistance with luggage upon arrival and departure.'),
(1, 'Guideline 4: Ensure that guest rooms are clean and well-maintained.'),
(1, 'Guideline 5: Provide complimentary amenities such as toiletries and refreshments.'),
(1, 'Guideline 6: Offer personalized recommendations for dining and local attractions.'),
(1, 'Guideline 7: Respond promptly to guest inquiries and requests.'),
(1, 'Guideline 8: Maintain a friendly and professional demeanor at all times.'),
(1, 'Guideline 9: Ensure guest safety and security throughout their stay.'),
(1, 'Guideline 10: Offer flexible check-in and check-out options when possible.'),
(1, 'Guideline 11: Provide efficient room service and dining options.'),
(1, 'Guideline 12: Offer recreational activities and entertainment for guests.'),
(1, 'Guideline 13: Keep guests informed about hotel events and promotions.'),
(1, 'Guideline 14: Address and resolve guest complaints promptly and effectively.'),
(1, 'Guideline 15: Maintain a clean and inviting lobby area for guests.'),
(1, 'Guideline 16: Offer assistance with transportation and travel arrangements.'),
(1, 'Guideline 17: Provide accessibility options for guests with special needs.'),
(1, 'Guideline 18: Offer rewards or loyalty programs for returning guests.'),
(1, 'Guideline 19: Implement eco-friendly practices to reduce environmental impact.'),
(1, 'Guideline 20: Continuously seek feedback from guests to improve service quality.');
